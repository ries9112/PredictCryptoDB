This is a guide for the competitor lift ticket prices data collection project managed by the Pricing team within Marketing Analytics
